import pickle
list1=['poorti','raja','putti']
fh=open('pickling.pkl','bw')
pickle.dump(list1,fh)
fh.close()

fo=open('pickling.pkl','rb')
list2=pickle.load(fo)
print(list2)